<script src="<?php echo e(url('assets/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/jquery-knob/jquery.knob.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(url('dist/js/adminlte.js')); ?>"></script>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<?php echo $__env->yieldPushContent('js'); ?>
<?php if(session('success')): ?>
    <script>
        toastr.success('<?php echo e(session('success')); ?>')
    </script>
<?php endif; ?>
<?php if(session('error')): ?>
    <script>
        toastr.error('<?php echo e(session('error')); ?>')
    </script>
<?php endif; ?>
<?php if(session('warning')): ?>
    <script>
        toastr.warning('<?php echo e(session('warning')); ?>')
    </script>
<?php endif; ?>
<?php if(session('info')): ?>
    <script>
        toastr.info('<?php echo e(session('info')); ?>')
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\Administrator\Documents\Dev\laravel\resources\views/layouts/script.blade.php ENDPATH**/ ?>
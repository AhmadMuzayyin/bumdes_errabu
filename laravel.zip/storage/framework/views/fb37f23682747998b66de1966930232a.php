<div>
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="/" class="brand-link">
            <img src="<?php echo e(url('logo.png')); ?>" width="100" alt="AdminLTE Logo"
                class="brand-image img-circle elevation-3" style="opacity: .8">
            <span class="brand-text font-weight-light">Bumdes Pintar</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">
                    <li class="nav-item">
                        <a href="<?php echo e(route('dashboard')); ?>"
                            class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                            <ion-icon class="nav-icon" name="home"></ion-icon>
                            <p>
                                Dashboard
                            </p>
                        </a>
                    </li>
                    <?php if(auth()->user()->role == 'admin'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('operator.index')); ?>"
                            class="nav-link <?php echo e(request()->routeIs('operator.*') ? 'active' : ''); ?>">
                            <ion-icon class="nav-icon" name="person-circle"></ion-icon>
                            <p>
                                Operator
                            </p>
                        </a>
                    </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('badan_usaha.index')); ?>"
                                class="nav-link <?php echo e(request()->routeIs('badan_usaha.*') ? 'active' : ''); ?>">
                                <ion-icon class="nav-icon" name="briefcase"></ion-icon>
                                <p>
                                    Badan Usaha
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('spending.index')); ?>"
                                class="nav-link <?php echo e(request()->routeIs('spending.*') ? 'active' : ''); ?>">
                               <ion-icon class="nav-icon" name="cash"></ion-icon>
                                <p>
                                    Dana Keluar
                                </p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('income.index')); ?>"
                            class="nav-link <?php echo e(request()->routeIs('income.*') ? 'active' : ''); ?>">
                            <ion-icon class="nav-icon" name="card"></ion-icon>
                            <p>
                                Dana Masuk
                            </p>
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>
</div>
<?php /**PATH C:\Users\Administrator\Documents\Dev\laravel\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>
<!-- Nav -->
<nav>
    <ul id="ownmenu" class="ownmenu">
        <li class="active"><a href="<?php echo e(url('/')); ?>">HOME</a></li>
        <li><a href="#potensi_desa"> Potensi Desa </a></li>
        <li><a href="#badan_usaha"> Badan Usaha </a></li>
        <li><a href="#keuangan"> Keuangan </a></li>
        <?php if(auth()->user()): ?>
            <li><a href="<?php echo e(route('dashboard')); ?>"> Dashboard </a></li>
        <?php else: ?>
            <li><a href="<?php echo e(route('login')); ?>"> Login </a></li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH C:\Users\Administrator\Documents\Dev\laravel\resources\views/landing/navbar.blade.php ENDPATH**/ ?>
<footer class="main-footer">
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="/">Bumdes Pintar</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>
<?php /**PATH C:\Users\Administrator\Documents\Dev\laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
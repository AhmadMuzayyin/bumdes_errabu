<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="card-title">Data Dana Masuk</h3>
                        </div>
                        <div class="col-right">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#addUsaha">
                                <ion-icon name="add"></ion-icon> Dana Masuk
                            </button>
                        </div>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Badan Usaha</th>
                                <th>Jumlah Dana</th>
                                <th>created_at</th>
                                <th>updated_at</th>
                                <th>
                                    <ion-icon name="settings"></ion-icon>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $income; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->badan_usaha->nama); ?></td>
                                    <td><?php echo e($item->nominal); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td>
                                        <?php if (isset($component)) { $__componentOriginale9eefe50b390207aad69b8e237e3dc7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9eefe50b390207aad69b8e237e3dc7d = $attributes; } ?>
<?php $component = App\View\Components\ActionButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('action-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ActionButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['edit' => 'edit-'.e($item->id).'','view' => 'detail-'.e($item->id).'','delete' => ''.e(route('income.destroy', $item->id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9eefe50b390207aad69b8e237e3dc7d)): ?>
<?php $attributes = $__attributesOriginale9eefe50b390207aad69b8e237e3dc7d; ?>
<?php unset($__attributesOriginale9eefe50b390207aad69b8e237e3dc7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9eefe50b390207aad69b8e237e3dc7d)): ?>
<?php $component = $__componentOriginale9eefe50b390207aad69b8e237e3dc7d; ?>
<?php unset($__componentOriginale9eefe50b390207aad69b8e237e3dc7d); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5 = $attributes; } ?>
<?php $component = App\View\Components\ModalForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ModalForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'edit-'.e($item->id).'','title' => 'Edit Dana Masuk','action' => ''.e(route('income.update', $item->id)).'']); ?>
                                            <?php if(Auth::user()->role == 'admin'): ?>
                                                <div class="form-group">
                                                    <label for="badan_usaha_id">Badan Usaha</label>
                                                    <select name="badan_usaha_id" id="badan_usaha_id"
                                                        class="form-control <?php $__errorArgs = ['badan_usaha_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        value="<?php echo e(old('badan_usaha_id')); ?>">
                                                        <option value="">-- Pilih Badan Usaha --</option>
                                                        <?php $__currentLoopData = $usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($val->id); ?>" <?php echo e($val->id == $item->badan_usaha_id ? 'selected' : ''); ?>><?php echo e($val->nama); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['badan_usaha_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback">
                                                            <?php echo e($message); ?>

                                                        </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            <?php else: ?>
                                                <input type="hidden" name="badan_usaha_id" value="<?php echo e($usaha->id); ?>">
                                            <?php endif; ?>
                                            <div class="form-group">
                                                <label for="nominal">Nominal</label>
                                                <input type="number" name="nominal" id="nominal"
                                                    class="form-control <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Nominal"
                                                    value="<?php echo e(old('nominal') ?? $item->originalNominal); ?>">
                                                <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e($message); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <input type="hidden" name="tanggal" value="<?php echo e(now()); ?>">
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5)): ?>
<?php $attributes = $__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5; ?>
<?php unset($__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5)): ?>
<?php $component = $__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5; ?>
<?php unset($__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal7bd65c16703908d5c783d25da14dff50 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7bd65c16703908d5c783d25da14dff50 = $attributes; } ?>
<?php $component = App\View\Components\ModalDefault::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ModalDefault::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'detail-'.e($item->id).'','title' => 'Detail Badan Usaha']); ?>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <tr>
                                                        <th>Nama Badan Usaha</th>
                                                        <td><?php echo e($item->badan_usaha->nama); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Operator</th>
                                                        <td><?php echo e($item->badan_usaha->user->nama); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Nominal</th>
                                                        <td><?php echo e($item->nominal); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Tanggal</th>
                                                        <td><?php echo e($item->tanggal); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>created_at</th>
                                                        <td><?php echo e($item->created_at); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>updated_at</th>
                                                        <td><?php echo e($item->updated_at); ?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7bd65c16703908d5c783d25da14dff50)): ?>
<?php $attributes = $__attributesOriginal7bd65c16703908d5c783d25da14dff50; ?>
<?php unset($__attributesOriginal7bd65c16703908d5c783d25da14dff50); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7bd65c16703908d5c783d25da14dff50)): ?>
<?php $component = $__componentOriginal7bd65c16703908d5c783d25da14dff50; ?>
<?php unset($__componentOriginal7bd65c16703908d5c783d25da14dff50); ?>
<?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5 = $attributes; } ?>
<?php $component = App\View\Components\ModalForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ModalForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addUsaha','title' => 'Tambah Dana Masuk','action' => ''.e(route('income.store')).'']); ?>
        <?php if(Auth::user()->role == 'admin'): ?>
            <div class="form-group">
                <label for="badan_usaha_id">Badan Usaha</label>
                <select name="badan_usaha_id" id="badan_usaha_id"
                    class="form-control <?php $__errorArgs = ['badan_usaha_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('badan_usaha_id')); ?>">
                    <option value="">-- Pilih Badan Usaha --</option>
                    <?php $__currentLoopData = $usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->id); ?>"><?php echo e($val->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['badan_usaha_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php else: ?>
            <input type="hidden" name="badan_usaha_id" value="<?php echo e($usaha->id); ?>">
        <?php endif; ?>
        <div class="form-group">
            <label for="nominal">Nominal</label>
            <input type="number" name="nominal" id="nominal" class="form-control <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="Nominal" value="<?php echo e(old('nominal')); ?>">
            <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <input type="hidden" name="tanggal" value="<?php echo e(now()); ?>">
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5)): ?>
<?php $attributes = $__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5; ?>
<?php unset($__attributesOriginal70de37fa3f6471d1a6119a87b2d18ba5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5)): ?>
<?php $component = $__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5; ?>
<?php unset($__componentOriginal70de37fa3f6471d1a6119a87b2d18ba5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(function() {
            $("#example1").DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Dana Masuk', 'activePage' => 'Dana Masuk'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\Dev\laravel\resources\views/income/index.blade.php ENDPATH**/ ?>
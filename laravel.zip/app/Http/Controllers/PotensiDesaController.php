<?php

namespace App\Http\Controllers;

class PotensiDesaController extends Controller
{
    //
}
